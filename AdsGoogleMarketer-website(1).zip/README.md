# AdsGoogleMarketer.com

A responsive Google Ads service website for Imran Khan, with:
- Public marketing website
- Contact/lead form
- Cloudflare Pages Functions API
- Cloudflare D1 database for leads and editable content
- Private admin dashboard at `/admin.html`
- Pricing editable from the dashboard
- User-provided hero image included at `public/assets/hero.png`

## Free hosting architecture
Cloudflare Pages can host the static website, and Pages Functions can provide server-side APIs. D1 stores leads and editable website content.

### 1) Create a Cloudflare Pages project
Connect this folder/repository to Cloudflare Pages. Build output directory: `public`. No build command is required for the static frontend.

### 2) Create a D1 database
Create a D1 database named `adsgooglemarketer-db`, then run `schema.sql` against it. Put the resulting database ID into `wrangler.toml`.

### 3) Bind D1
In the Pages project, add a D1 binding named `DB` pointing to your database.

### 4) Add a secret
In Pages project settings, add an environment variable/secret:
ADMIN_TOKEN = a long random secret that only you know.

Do NOT put the admin token inside HTML, JavaScript, GitHub, or public files.

### 5) Admin
After deployment, open:
`https://YOUR-DOMAIN/admin.html`

Enter the ADMIN_TOKEN. You can then view leads and change pricing. The token is sent only to your own API endpoint over HTTPS.

## Important
- This project does not contain your hosting passwords, Google Ads account credentials, or payment credentials.
- Replace placeholder policies with terms that match your actual business.
- If you later want a richer CMS (edit services, testimonials, hero text, etc.), the same D1-backed admin panel can be expanded.
