const defaultContent={services:[
{icon:"🎯",title:"Search Ads",text:"Keyword-focused campaigns designed to reach people actively searching for your services."},
{icon:"📊",title:"Campaign Optimization",text:"Ongoing review of search terms, bids, ads and targeting to improve campaign efficiency."},
{icon:"🔎",title:"Keyword Research",text:"Research and organization of relevant keywords, match types and negative keywords."},
{icon:"🛒",title:"Shopping Ads",text:"Product-focused campaigns for eligible e-commerce businesses."},
{icon:"▶️",title:"YouTube Ads",text:"Video advertising campaigns with audience and campaign setup support."},
{icon:"♻️",title:"Remarketing",text:"Reconnect with relevant visitors and audiences using remarketing campaigns."}],
pricing:[
{name:"Starter",price:"PKR 25,000",period:"/ month",featured:false,features:["Campaign setup","Keyword research","Monthly optimization","Performance summary"]},
{name:"Business",price:"PKR 45,000",period:"/ month",featured:true,features:["Campaign setup & management","Keyword + negative keyword research","Conversion tracking support","Regular optimization","Monthly reporting"]},
{name:"Custom",price:"Let's Talk",period:"",featured:false,features:["Multiple campaigns","Advanced tracking","Custom reporting","Strategy consultation","Tailored management"]}]};

async function loadContent(){
 try{const r=await fetch("/api/content");if(r.ok){const d=await r.json();return {...defaultContent,...d}}}catch(e){}
 return defaultContent;
}
function render(d){
 document.querySelector("#servicesGrid").innerHTML=d.services.map(x=>`<article class="card"><div class="icon">${x.icon||"✓"}</div><h3>${escapeHtml(x.title)}</h3><p>${escapeHtml(x.text)}</p></article>`).join("");
 document.querySelector("#pricingGrid").innerHTML=d.pricing.map(x=>`<article class="price-card ${x.featured?"featured":""}">${x.featured?'<span class="badge">POPULAR</span>':""}<h3>${escapeHtml(x.name)}</h3><div class="price">${escapeHtml(x.price)} <small>${escapeHtml(x.period||"")}</small></div><ul>${(x.features||[]).map(f=>`<li>${escapeHtml(f)}</li>`).join("")}</ul><a class="btn primary" href="#contact">Get Started</a></article>`).join("");
}
function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
document.querySelector(".menu-btn").onclick=()=>document.querySelector(".nav nav").classList.toggle("open");
document.querySelector("#year").textContent=new Date().getFullYear();
loadContent().then(render);
document.querySelector("#leadForm").addEventListener("submit",async e=>{
 e.preventDefault();const form=e.currentTarget,status=document.querySelector("#formStatus");
 const data=Object.fromEntries(new FormData(form).entries());status.textContent="Sending...";
 try{const r=await fetch("/api/leads",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});
 if(!r.ok)throw new Error();form.reset();status.textContent="Thank you. Your inquiry has been received."; }catch(err){status.textContent="Please use WhatsApp or email if the form is temporarily unavailable."}
});