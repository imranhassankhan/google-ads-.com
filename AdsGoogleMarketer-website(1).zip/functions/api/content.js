const DEFAULT_CONTENT={services:[
{icon:"🎯",title:"Search Ads",text:"Keyword-focused campaigns designed to reach people actively searching for your services."},
{icon:"📊",title:"Campaign Optimization",text:"Ongoing review of search terms, bids, ads and targeting to improve campaign efficiency."},
{icon:"🔎",title:"Keyword Research",text:"Research and organization of relevant keywords, match types and negative keywords."},
{icon:"🛒",title:"Shopping Ads",text:"Product-focused campaigns for eligible e-commerce businesses."},
{icon:"▶️",title:"YouTube Ads",text:"Video advertising campaigns with audience and campaign setup support."},
{icon:"♻️",title:"Remarketing",text:"Reconnect with relevant visitors and audiences using remarketing campaigns."}],
pricing:[
{name:"Starter",price:"PKR 25,000",period:"/ month",featured:false,features:["Campaign setup","Keyword research","Monthly optimization","Performance summary"]},
{name:"Business",price:"PKR 45,000",period:"/ month",featured:true,features:["Campaign setup & management","Keyword + negative keyword research","Conversion tracking support","Regular optimization","Monthly reporting"]},
{name:"Custom",price:"Let's Talk",period:"",featured:false,features:["Multiple campaigns","Advanced tracking","Custom reporting","Strategy consultation","Tailored management"]}]};
async function getContent(env){const row=await env.DB.prepare("SELECT value FROM settings WHERE key='content'").first();if(row)return JSON.parse(row.value);await env.DB.prepare("INSERT OR REPLACE INTO settings(key,value) VALUES('content',?)").bind(JSON.stringify(DEFAULT_CONTENT)).run();return DEFAULT_CONTENT}
export async function onRequestGet({env}){return Response.json(await getContent(env))}
export async function onRequestPost({request,env}){if(request.headers.get("Authorization")!==`Bearer ${env.ADMIN_TOKEN}`)return new Response("Unauthorized",{status:401});const body=await request.json();const current=await getContent(env);const next={...current,...body};await env.DB.prepare("INSERT OR REPLACE INTO settings(key,value) VALUES('content',?)").bind(JSON.stringify(next)).run();return Response.json(next)}